package com.example.grade_calculator

/**
 * Data class representing a Course with CA and Exam marks.
 * Supports null values for incomplete entries.
 */
data class Course(
    val name: String,
    val ca: Int?,
    val exam: Int?
) {
    /**
     * Checks if the course has both CA and Exam marks.
     */
    val isComplete: Boolean
        get() = ca != null && exam != null

    /**
     * Calculates the average of CA and Exam marks.
     * Returns null if either mark is missing.
     */
    val average: Double?
        get() = if (isComplete) (ca!! + exam!!) / 2.0 else null

    /**
     * Assigns a grade based on the average score.
     * Returns null if the course is incomplete.
     */
    val grade: String?
        get() = average?.let { calculateGrade(it) }

    /**
     * Determines if the course is marked as incomplete.
     */
    val isIncomplete: Boolean
        get() = !isComplete

    companion object {
        /**
         * Higher-order function to calculate grade based on score.
         * Uses lambda for flexible grade calculation.
         */
        val calculateGrade: (Double) -> String = { score ->
            when (score.toInt()) {
                in 0..34 -> "F"
                in 35..44 -> "D"
                in 45..49 -> "D+"
                in 50..54 -> "C"
                in 55..64 -> "C+"
                in 65..69 -> "B"
                in 70..79 -> "B+"
                in 80..89 -> "A"
                in 90..100 -> "A+"
                else -> "Invalid"
            }
        }
    }
}

/**
 * Data class representing a Student with their courses.
 */
data class Student(
    val name: String,
    val id: String,
    val courses: MutableList<Course>
) {
    /**
     * Validates that the student has a valid name and ID.
     */
    val isValid: Boolean
        get() = name.isNotBlank() && id.isNotBlank()

    /**
     * Returns the number of complete courses.
     */
    val completedCoursesCount: Int
        get() = courses.count { it.isComplete }

    /**
     * Returns the number of incomplete courses.
     */
    val incompleteCoursesCount: Int
        get() = courses.count { it.isIncomplete }

    /**
     * Calculates the overall average across all complete courses.
     * Returns null if no courses are complete.
     */
    val overallAverage: Double?
        get() {
            val completeCourses = courses.filter { it.isComplete }
            return if (completeCourses.isNotEmpty()) {
                completeCourses.mapNotNull { it.average }.average()
            } else null
        }

    /**
     * Returns the overall grade based on overall average.
     */
    val overallGrade: String?
        get() = overallAverage?.let { Course.calculateGrade(it) }

    /**
     * Processes all courses using a higher-order function.
     */
    fun processCourses(action: (Course) -> Unit) {
        courses.forEach(action)
    }
}
