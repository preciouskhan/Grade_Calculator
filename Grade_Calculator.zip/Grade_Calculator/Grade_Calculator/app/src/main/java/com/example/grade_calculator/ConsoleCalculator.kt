package com.example.grade_calculator

/**
 * Console-based Grade Calculator
 * 
 * This program calculates student grades based on CA and Exam marks.
 * It demonstrates Kotlin fundamentals:
 * - Data classes
 * - Lambda functions
 * - Higher-order functions
 * - Null safety features
 * - Mutable lists
 * - Conditional statements
 */
fun main() {
    println("╔════════════════════════════════════════════════════════╗")
    println("║          STUDENT GRADE CALCULATOR (Console)             ║")
    println("╚════════════════════════════════════════════════════════╝")
    println()

    // Collect student information with null safety
    val student = createStudent()

    // Display results
    displayResults(student)
}

/**
 * Creates a Student object by collecting input from the console.
 * Uses Kotlin's safe call (?.) and Elvis operator (?:) for null handling.
 */
private fun createStudent(): Student {
    // Get student name with validation
    val name = getInput("Enter Student Name: ") ?: "Unknown"

    // Get student ID with validation
    val id = getInput("Enter Student ID: ") ?: "0000"

    println("\n─── Course Entry (max 6 courses, enter blank name to stop) ───")

    // Create mutable list of courses
    val courses = mutableListOf<Course>()

    // Allow up to 6 courses with option to stop early
    for (i in 1..MAX_COURSES) {
        println("\n>>> Course $i of $MAX_COURSES")

        // Get course name with option to stop
        val courseName = getInput("Course Name (or press Enter to stop): ")

        // Check if user wants to stop entering courses
        if (courseName.isNullOrBlank()) {
            println("\n✓ Finished entering courses")
            break
        }

        // Get CA mark (nullable)
        val caMark = getOptionalInt("CA Mark (press Enter if missing): ")

        // Get Exam mark (nullable)
        val examMark = getOptionalInt("Exam Mark (press Enter if missing): ")

        // Validate marks if provided
        if (caMark != null && !isValidMark(caMark)) {
            println("⚠ Warning: CA mark should be between 0 and 100")
        }
        if (examMark != null && !isValidMark(examMark)) {
            println("⚠ Warning: Exam mark should be between 0 and 100")
        }

        // Create course using data class
        val course = Course(
            name = courseName,
            ca = caMark,
            exam = examMark
        )

        courses.add(course)

        // Show status
        val status = if (course.isIncomplete) " [INCOMPLETE]" else ""
        println("✓ Course added$status")
    }

    return Student(name = name, id = id, courses = courses)
}

/**
 * Displays the grade calculation results.
 * Uses Kotlin's higher-order functions (forEach, lambda expressions).
 */
private fun displayResults(student: Student) {
    println("\n")
    println("════════════════════════════════════════════════════════")
    println("                    RESULTS")
    println("════════════════════════════════════════════════════════")
    println()
    println("Student Name: ${student.name}")
    println("Student ID: ${student.id}")
    println("Total Courses: ${student.courses.size}")
    println("Completed: ${student.completedCoursesCount}")
    println("Incomplete: ${student.incompleteCoursesCount}")
    println()
    println("────────────────────────────────────────────────────────")
    println("                   COURSE RESULTS")
    println("────────────────────────────────────────────────────────")
    println()

    // Use Kotlin's forEach higher-order function to process courses
    // Lambda function to process each course
    val processCourse: (Course) -> Unit = { course ->
        displayCourseResult(course)
    }

    // Apply to all courses
    student.courses.forEach(processCourse)

    // Display summary
    displaySummary(student)

    println("════════════════════════════════════════════════════════")
    println("                    END OF REPORT")
    println("════════════════════════════════════════════════════════")
}

/**
 * Displays individual course result.
 * Uses Kotlin's safe call (?.) and Elvis operator (?:).
 */
private fun displayCourseResult(course: Course) {
    println("┌─────────────────────────────────────────┐")
    println("│ Course: ${course.name.padEnd(35)}│")
    println("├─────────────────────────────────────────┤")

    if (course.isIncomplete) {
        // Handle incomplete course using Kotlin null safety
        println("│ Status: INCOMPLETE                      │")
        println("│ CA Mark:   ${(course.ca?.toString() ?: "Not Provided").padEnd(30)}│")
        println("│ Exam Mark: ${(course.exam?.toString() ?: "Not Provided").padEnd(30)}│")
    } else {
        // Calculate average using lambda
        val calculateAverage: (Int, Int) -> Double = { ca, exam ->
            (ca + exam) / 2.0
        }

        val average = calculateAverage(course.ca!!, course.exam!!)
        val grade = Course.calculateGrade(average)

        println("│ CA Mark:   ${course.ca.toString().padEnd(35)}│")
        println("│ Exam Mark: ${course.exam.toString().padEnd(35)}│")
        println("│ Average:   ${String.format("%.1f", average).padEnd(35)}│")
        println("│ Grade:     ${grade.padEnd(35)}│")
    }

    println("└─────────────────────────────────────────┘")
    println()
}

/**
 * Displays overall summary using Kotlin's Elvis operator.
 */
private fun displaySummary(student: Student) {
    println("────────────────────────────────────────────────────────")
    println("                     SUMMARY")
    println("────────────────────────────────────────────────────────")
    println()

    // Use Elvis operator for null safety
    val overallAvg = student.overallAverage
    val overallGrade = student.overallGrade

    if (overallAvg != null && overallGrade != null) {
        println("Overall Average: ${String.format("%.1f", overallAvg)}")
        println("Overall Grade: $overallGrade")
    } else {
        println("No complete courses to calculate overall grade.")
        println("Please complete all courses for overall calculation.")
    }

    // Calculate GPA equivalent (optional enhancement)
    val gpa = overallAvg?.let { calculateGPA(it) }
    if (gpa != null) {
        println("GPA (4.0 Scale): ${String.format("%.2f", gpa)}")
    }

    println()
}

/**
 * Converts percentage to GPA (4.0 scale).
 * Higher-order function that takes a double and returns a double.
 */
private fun calculateGPA(percentage: Double): Double {
    return when (percentage.toInt()) {
        in 90..100 -> 4.0
        in 80..89 -> 3.5
        in 70..79 -> 3.0
        in 65..69 -> 2.5
        in 55..64 -> 2.0
        in 50..54 -> 1.5
        in 45..49 -> 1.0
        else -> 0.0
    }
}

/**
 * Gets input from console with null safety.
 * Uses Elvis operator to provide default value.
 */
private fun getInput(prompt: String): String? {
    print(prompt)
    return readLine()?.trim()
}

/**
 * Gets optional integer input (can be blank for null).
 * Returns null if input is blank or invalid.
 */
private fun getOptionalInt(prompt: String): Int? {
    print(prompt)
    val input = readLine()
    return input?.toIntOrNull()
}

/**
 * Validates if a mark is within valid range.
 */
private fun isValidMark(mark: Int): Boolean {
    return mark in 0..100
}

/**
 * Extension property to access courses from Student in console display.
 * This is a workaround since we're accessing student.courses in a top-level function.
 */
private val courses: List<Course>
    get() = throw IllegalStateException("Use student.courses instead")

// Extension function on Student to get courses (more Kotlin-idiomatic)
private fun Student.getCourses(): List<Course> = this.courses
