package com.example.grade_calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Main Activity for the Grade Calculator Android App.
 * Provides a GUI for entering student information and calculating grades.
 */
class MainActivity : AppCompatActivity() {

    // Store up to 6 courses using Kotlin's mutable list
    private val courses = mutableListOf<Course>()

    // Lambda function for calculating average
    private val calculateAverage: (Int, Int) -> Double = { ca, exam ->
        (ca + exam) / 2.0
    }

    // Higher-order function for grade calculation
    private fun calculateGrade(score: Double): String = Course.calculateGrade(score)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        val etName = findViewById<EditText>(R.id.etName)
        val etId = findViewById<EditText>(R.id.etId)
        val etCourseName = findViewById<EditText>(R.id.etCourseName)
        val etCA = findViewById<EditText>(R.id.etCA)
        val etExam = findViewById<EditText>(R.id.etExam)
        val btnAddCourse = findViewById<Button>(R.id.btnAddCourse)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val btnReset = findViewById<Button>(R.id.btnReset)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        // Set up click listener for adding courses
        btnAddCourse.setOnClickListener {
            addCourse(etCourseName, etCA, etExam, tvResult)
        }

        // Set up click listener for calculating grades
        btnCalculate.setOnClickListener {
            calculateGrades(etName, etId, tvResult)
        }

        // Set up click listener for resetting
        btnReset.setOnClickListener {
            resetApplication(etName, etId, etCourseName, etCA, etExam, tvResult)
        }
    }

    /**
     * Adds a new course to the student's course list.
     * Uses Kotlin null safety features (? and ?:) for safe handling.
     */
    private fun addCourse(
        etCourseName: EditText,
        etCA: EditText,
        etExam: EditText,
        tvResult: TextView
    ) {
        // Validate course limit
        if (courses.size >= MAX_COURSES) {
            Toast.makeText(this, "Maximum $MAX_COURSES courses allowed", Toast.LENGTH_SHORT).show()
            return
        }

        // Get course name with null safety
        val courseName = etCourseName.text.toString().trim()

        // Validate course name
        if (courseName.isBlank()) {
            Toast.makeText(this, "Please enter a course name", Toast.LENGTH_SHORT).show()
            return
        }

        // Parse CA and Exam marks with null safety
        // Uses Kotlin's safe call (?.) and Elvis operator (?:)
        val caMark = etCA.text.toString().toIntOrNull()
        val examMark = etExam.text.toString().toIntOrNull()

        // Validate marks are within range (optional enhancement)
        if (caMark != null && (caMark < 0 || caMark > 100)) {
            Toast.makeText(this, "CA mark must be between 0 and 100", Toast.LENGTH_SHORT).show()
            return
        }

        if (examMark != null && (examMark < 0 || examMark > 100)) {
            Toast.makeText(this, "Exam mark must be between 0 and 100", Toast.LENGTH_SHORT).show()
            return
        }

        // Create course using data class
        val course = Course(
            name = courseName,
            ca = caMark,
            exam = examMark
        )

        // Add to courses list
        courses.add(course)

        // Show confirmation using Kotlin's string templates
        val status = if (course.isIncomplete) " (Incomplete)" else ""
        Toast.makeText(this, "Course Added$status", Toast.LENGTH_SHORT).show()

        // Clear input fields
        etCourseName.text.clear()
        etCA.text.clear()
        etExam.text.clear()

        // Update result preview
        updateResultPreview(tvResult)
    }

    /**
     * Calculates grades for all courses and displays results.
     * Uses Kotlin's higher-order functions and lambdas.
     */
    private fun calculateGrades(
        etName: EditText,
        etId: EditText,
        tvResult: TextView
    ) {
        // Get student name and ID with null safety
        val name = etName.text.toString().trim()
        val id = etId.text.toString().trim()

        // Validate student information
        if (name.isBlank()) {
            Toast.makeText(this, "Please enter student name", Toast.LENGTH_SHORT).show()
            return
        }

        if (id.isBlank()) {
            Toast.makeText(this, "Please enter student ID", Toast.LENGTH_SHORT).show()
            return
        }

        if (courses.isEmpty()) {
            Toast.makeText(this, "Please add at least one course", Toast.LENGTH_SHORT).show()
            return
        }

        // Create student object using data class
        val student = Student(
            name = name,
            id = id,
            courses = courses
        )

        // Build result string using StringBuilder
        val resultText = StringBuilder()

        // Header using Kotlin's string templates
        resultText.append("═══════════════════════════════\n")
        resultText.append("       STUDENT GRADE REPORT\n")
        resultText.append("═══════════════════════════════\n\n")
        resultText.append("Student Name: ${student.name}\n")
        resultText.append("Student ID: ${student.id}\n")
        resultText.append("Total Courses: ${student.courses.size}\n")
        resultText.append("Completed: ${student.completedCoursesCount}\n")
        resultText.append("Incomplete: ${student.incompleteCoursesCount}\n\n")
        resultText.append("───────────────────────────────────────\n")
        resultText.append("              COURSE RESULTS\n")
        resultText.append("───────────────────────────────────────\n\n")

        // Use Kotlin's forEach higher-order function to process courses
        student.processCourses { course ->
            resultText.append("Course: ${course.name}\n")

            // Use Kotlin's Elvis operator (?:) for null handling
            val average = course.average
            val grade = course.grade

            if (course.isIncomplete) {
                resultText.append("Status: INCOMPLETE\n")
                resultText.append("CA Mark: ${course.ca ?: "Not Provided"}\n")
                resultText.append("Exam Mark: ${course.exam ?: "Not Provided"}\n")
            } else {
                // Safe calculation using nullable types
                val avg = average ?: 0.0
                val grd = grade ?: "N/A"
                resultText.append("CA Mark: ${course.ca}\n")
                resultText.append("Exam Mark: ${course.exam}\n")
                resultText.append("Average: ${String.format("%.1f", avg)}\n")
                resultText.append("Grade: $grd\n")
            }
            resultText.append("\n───────────────────────────────────────\n\n")
        }

        // Add overall summary
        val overallAvg = student.overallAverage
        val overallGrade = student.overallGrade

        resultText.append("═══════════════════════════════\n")
        resultText.append("             SUMMARY\n")
        resultText.append("═══════════════════════════════\n\n")

        if (overallAvg != null && overallGrade != null) {
            resultText.append("Overall Average: ${String.format("%.1f", overallAvg)}\n")
            resultText.append("Overall Grade: $overallGrade\n")
        } else {
            resultText.append("No complete courses to calculate overall grade.\n")
        }

        resultText.append("\n═══════════════════════════════\n")

        // Display results
        tvResult.text = resultText.toString()
    }

    /**
     * Updates the result preview showing added courses.
     */
    private fun updateResultPreview(tvResult: TextView) {
        val preview = StringBuilder()
        preview.append("Added Courses:\n")
        courses.forEachIndexed { index, course ->
            val status = if (course.isIncomplete) " [Incomplete]" else ""
            preview.append("${index + 1}. ${course.name}$status\n")
        }
        preview.append("\n${courses.size}/$MAX_COURSES courses added")
        tvResult.text = preview.toString()
    }

    /**
     * Resets the application to initial state.
     */
    private fun resetApplication(
        etName: EditText,
        etId: EditText,
        etCourseName: EditText,
        etCA: EditText,
        etExam: EditText,
        tvResult: TextView
    ) {
        // Clear all input fields
        etName.text.clear()
        etId.text.clear()
        etCourseName.text.clear()
        etCA.text.clear()
        etExam.text.clear()

        // Clear courses list
        courses.clear()

        // Clear result display
        tvResult.text = ""

        Toast.makeText(this, "Application Reset", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val MAX_COURSES = 6
    }
}
